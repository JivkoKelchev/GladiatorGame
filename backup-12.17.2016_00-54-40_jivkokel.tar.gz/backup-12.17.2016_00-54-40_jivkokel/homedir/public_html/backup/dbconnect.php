<?php

/* връзка с база данни */

$servername = "localhost"; $username1 = "jivkokel"; $password1 = "kzYn[Kt4X)9A";

$dbname = "jivkokel_pics";

$conn = mysqli_connect($servername, $username1, $password1, $dbname);

if (!$conn) { die("Connection failed: " . mysqli_connect_error()); }

?>