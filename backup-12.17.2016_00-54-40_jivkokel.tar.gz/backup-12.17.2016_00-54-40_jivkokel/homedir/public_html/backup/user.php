<!DOCTYPE html>

<html>

<head>

<meta charset="utf-8">

</head>

<body>

<form action="upload.php" method="post">

username

<input type="text" name="username" size=20 >

password

<input type="password" name="pass" size=10 >

confirm password

<input type="password" name="pass1" size=10 >

<input type="submit" value="Register" name='submit'>


</body>

</html>