<?php

/* форма за качване на снимки */

$servername = "localhost"; $username = "jivkokel"; $password = "kzYn[Kt4X)9A";

$dbname = "jivkokel_pics";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) { die("Connection failed: " . mysqli_connect_error()); }

?>

<!DOCTYPE html>

<html>

<head>

<meta charset="utf-8">

</head>

<body>

<form action="upload.php" method="post" enctype="multipart/form-data">

Изберете снимка:

<br>

<input type="file" name="fileToUpload" id="fileToUpload">

<br>

<input type="text" name="description" size=50 maxlenght=255>

<br>

тип на снимката

<br>

<?php
$sql_query = "SELECT * FROM pictype";

$result = mysqli_query($conn, $sql_query);

if (mysqli_num_rows($result) > 0) {

        echo '<select name = "pictypeID" >';

        echo '<option value="" > изберете тип';

	while($row = mysqli_fetch_assoc($result)) {
	

	   echo '<option value="'.$row["pictypeID"].'" >'. $row["pictype"] ;
	
          } 
        echo '</select>';
}
else {

echo "0 results";

}

echo ' <br> Държава <br>';

$sql_query = "SELECT * FROM country";

$result = mysqli_query($conn, $sql_query);

if (mysqli_num_rows($result) > 0) {

       echo '<select name="countryID">';
	
         echo '<option value="" > изберете държава';

	while($row = mysqli_fetch_assoc($result)) {
	
	   echo '<option value="'.$row["countryID"].'" >'.$row["country"] ;
	
          } 
          echo '</select>';
}
else {

echo "0 results";

}
?>

<br>

<input type='text' name='country' value='' size=50 maxlenght=255>

<br>

<input type="submit" value="Upload Image" name="submit">

</form>

</body>

</html>
<?php

mysqli_close($conn);

?>
