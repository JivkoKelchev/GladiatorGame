<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Галерия на Живко</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<?php include "navig.php"; ?>
<div class="album">
	<h3> Последно качени снимки </h3>
	<?php	
	include "dbconnect.php";  
	$sql_query = "SELECT * 
                     FROM pics  
                     order by upload_date DESC limit 0,2";
	$result = mysqli_query($conn, $sql_query);
	if (mysqli_num_rows($result) > 0) {
		while($row = mysqli_fetch_assoc($result)) {	
		echo '<button><img src="'.$row["filename"].'" alt="last pics" style="height:228px;"></button> <br>';	
		}       
	} 
?>
</body>

</html>