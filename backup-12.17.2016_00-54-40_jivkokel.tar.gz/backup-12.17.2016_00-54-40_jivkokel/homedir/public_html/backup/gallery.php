<?php session_start(); ?>
<!DOCTYPE html>

<html>

<head>
	<meta charset="utf-8">
	<title>Галерия на Живко</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="gallery.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<script src="gallery.js"> </script>

<style type="text/css"> 
.pic{
width = 100%;
}
body .modal{
width: 100%;
    margin: 0px;
    pading: 0px;
    background-color: rgba(0,0,0,0.3);

}
.modal .modal-content {
border-radius:0;
	color:#F2EEB3;
    width: 100%;
max-width: 5000px;
    margin: 0px;
    pading: 0px;
    background-color: #8C6954;
    box-shadow: 10px 10px rgba(0,0,0,0);
}
.modal .modal-content .modal-body{

    
    width: 100%;
max-width: 5000px;

}
.carousel-inner .item {
display:block;
hight:100%;
width: auto;
margin: 0;
}
	</style>
</head>

<body>

<?php include "navig.php";
include 'functions.php';
 ?>

<!-- 
///////////////////////////////////////////////////////////////////////////////////////////
/форма за тип на снимките и държава. Проверява в базата данни за възможностите за селекция/
///////////////////////////////////////////////////////////////////////////////////////////
-->
<div class="row">
<div class="col-xs-12 col-md-3" id="filter">
	<form action="<?php echo "$_SERVER[PHP_SELF]"; ?>" method="post">
	Изберете тип <br>
		<select name="pictypeID">
			<option value="" > всички
			<?php
			include "dbconnect.php";
			$submit=$_POST['submit'];
			$pictypeID=$_POST["pictypeID"];
			$countryID=$_POST["countryID"];
			$sql_query = "SELECT distinct pics.pictypeID, pictype.pictype
        	             FROM pics
        	             join pictype 
        	             on pics.pictypeID= pictype.pictypeID";
			$result = mysqli_query($conn, $sql_query);
			if (mysqli_num_rows($result) > 0) {
				while($row = mysqli_fetch_assoc($result)) {	
					if ($row["pictypeID"]==$pictypeID){
						$selected=" selected";
					} else {
						$selected="";
					}
				echo '<option value="'.$row["pictypeID"].'" '.$selected.' >'. $row["pictype"] ;	
				}       
			}
			?>
		</select>
		<br>Изберете държава<br>
		<select name="countryID">
			<option value=""> всички
			<?php
	
			$sql_query = "SELECT distinct pics.countryID, country.country
		                FROM pics
		                join country 
		                on pics.countryID= country.countryID";
			$result = mysqli_query($conn, $sql_query);
			if (mysqli_num_rows($result) > 0) {
				while($row = mysqli_fetch_assoc($result)) {	
					if ($row["countryID"]==$countryID){
						$selected1=" selected";
					} else {
						$selected1="";
					}
				echo ' <option value="'.$row["countryID"].'"'.$selected1.' >'. $row["country"] ;	
				}        
			}
			?>
		</select>
		<br><br>
		<input type = "submit" value="Избери" name="submit">
	</form>
</div>

<!-- 
//////////////////////////////////////////////////
/Проверява стойноста на $submit и прави селекция./
//////////////////////////////////////////////////
-->

<div class="col-xs-12 col-md-9" id="content">
<div class="row">

		<?php
		$id=0;  //използва се за брояч на селецтираните снимки. поставя се в id на li елемента за ползване на jQuery
		if (!$submit) {
			$sql_query = "SELECT * 
			              FROM pics  
			              order by upload_date desc ";
			$result = mysqli_query($conn, $sql_query);
			if (mysqli_num_rows($result) > 0) {
				while( $row = mysqli_fetch_assoc($result)) {	
					echo '
					
					<div class="col-xs-12 col-md-3 pics" >
						<div class="picholder" id="picholder'.$id.'">
							<img id="loader_img" src="Images/loader.gif">
							<img class="pic" id="img'.$id.'" src="'.$row["filename"].'" alt="'.$row["description"].'" style="width:100%;">
							
						</div>';
						$_SESSION['picID']=$row['picID'];
						$id++;
						comments();
						
					echo ' 
					
					</div>';
				}      
			}
		}
		if ($submit == "Избери") {
			$where='where 1';
			if ( $pictypeID !== "") {   
				$where.=" and pictypeID = $pictypeID";
			} 
			if ($countryID !== "") {
				$where.=" and countryID = $countryID";
			} 
			$sql_query = "SELECT * 
 		               FROM pics  
 		               $where
 		               order by upload_date desc
 		               ";
			$result = mysqli_query($conn, $sql_query);
			if (mysqli_num_rows($result) > 0) {
				 while($row = mysqli_fetch_assoc($result)) {
					echo '
					
					<div class="col-xs-12 col-md-3 pic">
					     <div class="picholder" id="picholder'.$id.'">
						<img class="pic" id="img'.$id.'" src="'.$row["filename"].'" alt="'.$row["description"].'" style="width:100%;">
						<h3>'.$row["description"].'</h3>
					     </div>';
					$_SESSION['picID']=$row['picID'];
					$id++;
					comments();
					 echo '
					 
					 </div>';	
				}      
			}
		} 
	?>
	</div>    <!-- затватя row level 2 -->

</div>         <!-- затватя row -->
</div>          <!-- затватя content c  -->


 <!-- ////////////////////////////
      //    Opit za modal 1     //
      ////////////////////////////   
-->
<div class="modal" id="modal-gallery" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button class="close" type="button" data-dismiss="modal" style="color:white";>×</button>
				<h3 class="modal-title"></h3>
			</div>
			<div class="modal-body">
				<div id="modal-carousel" class="carousel slide" data-ride="carousel" data-interval="false">
					<div class="carousel-inner" role="listbox">           
					</div>
					<a class="carousel-control left" href="#modal-carousel" data-slide="prev"><i class="glyphicon glyphicon-chevron-left"></i></a>
					<a class="carousel-control right" href="#modal-carousel" data-slide="next"><i class="glyphicon glyphicon-chevron-right"></i></a>
				</div>
			</div>
			<div class="modal-footer">
				<button class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>

</body>
</html>