$(document).ready(function() {
	/* activate the carousel*/
	/*$("#modal-carousel").carousel({interval:false});*/
	/* change modal title when slide changes */
	$("#modal-carousel").on("slid.bs.carousel", function () {
		$(".modal-title")
		.html($(this)
		.find(".active")
		.attr("alt"));
	}); 
	/* when clicking a thumbnail */
	$(".pic").click(function(){
		
		var content = $(".carousel-inner");
		var title = $(".modal-title");
		content.empty();  
		title.empty();
  	var id = this.id;  
     var repo = $(".pic");
    var repoCopy = repo.clone();
    repoCopy.removeClass("pic");
     repoCopy.addClass("item");
     var active = repoCopy.filter("#" + id);
  
    active.addClass("active");
   title.html(active.find("img").attr("alt"));
  	content.append(repoCopy);

    // show the modal
  	$("#modal-gallery").modal("show");
  	
  	
  	$('#modal').on('show.bs.modal', function () {
       $(this).find('.modal-body').css({
              width:'auto', //probably not needed
              height:'auto', //probably not needed 
              'max-height':'100%'
       });
});
  });



function carouselNormalization() {
	var items = $('.item'), //grab all slides
	heights = [], //create empty array to store height values
	tallest; //create variable to make note of the tallest slide

	if (items.length) {
		function normalizeHeights() {
			items.each(function() { //add heights to array
				heights.push($(this).height()); 
			});
	        	tallest = Math.max.apply(null, heights); //cache largest value
	        	items.each(function() {
				$(this).css('min-height',tallest + 'px');
			});
    		};
		normalizeHeights();

		$(window).on('resize orientationchange', function () {
			tallest = 0, heights.length = 0; //reset vars
        		items.each(function() {
            			$(this).css('min-height','0'); //reset min-height
        		}); 
        	normalizeHeights(); //run it again 
		});
	}
}
carouselNormalization();

// Show the loading image.
//$('.pic').hide();
$('#loader_img').show();

// When main image loads:
$('.pic').on('load', function(){
  // hide the loading image.
  $('#loader_img').hide(); 
});


});