<?php
session_start(); // Starting Session
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Галерия на Живко</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<div id="main">

	<div id="login">
	<h2>Моля въведете потребителското си име и парола</h2>
	<form action="" method="post">
	<label>UserName :</label>
	<input id="name" name="username" placeholder="username" type="text">
	<label>Password :</label>
	<input id="password" name="password" placeholder="**********" type="password">
	<input name="submit" type="submit" value=" Login ">
	<span><?php echo $error; ?></span>
	</form>
	</div>


<?php
$error=''; // Variable To Store Error Message
if (isset($_POST['submit'])) {
if (empty($_POST['username']) || empty($_POST['password'])) {
$error = "Въведете потребителското си име и парола!";
echo '<script> alert("'.$error.'") </script>';
}
else
{
// Define $username and $password
$username=$_POST['username'];
$password=$_POST['password'];

include "dbconnect.php";

/*?// To protect MySQL injection for Security purpose
$username = stripslashes($username);
$password = stripslashes($password);
$username = mysql_real_escape_string($username);
$password = mysql_real_escape_string($password);*/


// SQL query to fetch information of registerd users and finds user match.



$query = "select * from user where pass = '$password' AND username = '$username' ";
$result=mysqli_query($conn,$query);
$rows = mysqli_num_rows($result);
if ($rows == 1) {
$_SESSION['login_user']=$username; // Initializing Session
$row = mysqli_fetch_assoc($result);
$_SESSION['login_userID']=$row['userID']; // запазшаме userID  за да го ползшам при качване на коментари
//header("location: profile.php"); // Redirecting To Other Page 
echo "Добре дощъл ".$_SESSION['login_user']."  <a href='/index.php'> 'Начало' </a>" ;
} else {
$error = "Грешно име или парола!";
echo '<script> alert("'.$error.'") </script>';
}
}
}
?>


</body>
</html>