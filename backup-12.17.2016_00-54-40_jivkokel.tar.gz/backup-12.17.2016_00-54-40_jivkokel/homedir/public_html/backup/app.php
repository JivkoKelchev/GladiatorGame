<head>
	<meta charset="utf-8">
	<title>Галерия на Живко</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	
	<script>
	$(document).ready(function(){
   		 $("#hide").click(function(){
        		$("p").hide();
   		 });
    		$("#show").click(function(){
        		$("p").show();
    		});
	});
	</script>
	
	<style>
	html,body,.container,.row,.well,.comments {height: 100%;}

	* {
	    box-sizing: border-box;
	}

	.height-responsive {	
		display:block;
		height: 100%;
		max-height: 600px;
		margin: auto;
		border: 2px solid black;
		position: relative;
	}
	.next1 {
		color:red;
		display: block;
		position:absolute;
		top: 50%;
		right: 15px;
		
		
	}
	.prev1 {
		color:red;
		display: block;
		position:absolute;
		left: 15px;
		top: 50%;	
	}
	.height-responsive-img {
		display:block;
		width: auto;
		height:auto;
		max-width: 100%;
		
		max-height: 100%;
		margin: auto;
	}
	.comments {
		display:inline-block;
		height: 100%;
		max-height: 610px;
		background-color:lightblue;
		width: 25%;
		float: left;
		
	}
	.kartinka {
		display:block;
		position: relative;
		border: 5px solid black;
		margin: auto;
		width: 75%;
		float: left
		/*/width: 50%;*/
	}
	
	</style>
</head>
<!--<h1>
tova e test za razglejdane na snimki
</h1>-->




<div class="well">
	<div class="warp">
		<div class="kartinka">
			
		 
				<img class="height-responsive-img" id="show" src="http://jivko.kelchev.uchenici.bg/upload/IMAG2238.jpg" >
				<span class="next1">NEXT</span>
				<span class="prev1">PREV</span>
				
		</div>
		<div class="comments"> <p id="hide"> tuk shte sa komentarite </p> </div>
			
	</div>
<div>