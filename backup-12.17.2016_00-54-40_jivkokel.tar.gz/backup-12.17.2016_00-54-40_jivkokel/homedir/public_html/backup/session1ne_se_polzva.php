
<meta charset="utf-8">


<?php
include 'dbconnect.php';
$usernamelogin=$_POST['usernamelogin'];
$passlogin=$_POST['passlogin'];
$submit=$_POST["изход"];

$sql_query="select username from user where username = '$usernamelogin' and pass = '$passlogin'";
$result=mysqli_query($conn,$sql_query);
if (mysqli_num_rows($result) > 0) {
$row = mysqli_fetch_assoc($result);
$_SESSION['username']=$row['username'];
/*include 'index.php';*/
echo '<script type="text/javascript">
location.replace("index.php");
</script>' ;
exit;
} else {
echo "<script> alert ('Грешни потребителско име или парола') </script>";
/*echo $usernamelogin.'   '.$passlogin.'  '.$sql_query; */
header("Location: http/jivko.kelchev.uchenici.bg/index.php") ;/*include 'index.php';*/
exit;
}

if ($submit = "изход"){
session_destroy();header("Location: http/jivko.kelchev.uchenici.bg/index.php") ;
exit;
}
?>