<?php
session_start();
include "dbconnect.php";
$sql="Select* from pictures where picID=".$_GET[picID];
echo $sql;
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_assoc($result);
echo json_encode($row);
?>