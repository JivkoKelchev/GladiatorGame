<form method='post'>
	<input type='submit' name='send' value='send'>
</form>
<?php
if (isset ($_POST['send'])){
$to      = 'jivko.r.kelchev@gmail.com';
$subject = 'the subject';
$message = 'hello';
$headers = 'From: webmaster@example.com' . "\r\n" .
    'Reply-To: webmaster@example.com' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();

mail($to, $subject, $message, $headers);
}
?> 