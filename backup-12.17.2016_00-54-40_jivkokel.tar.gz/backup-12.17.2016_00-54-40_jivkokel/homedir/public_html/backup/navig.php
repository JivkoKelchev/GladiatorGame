<!DOCTYPE html>

<html>

<head>
  <meta charset="utf-8">
  <title>Галерия на Живко</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>

<body>

<nav class = "navbar navbar-default navbar-custom" id='nav'>
	<div class="container-fluid">
	<ul class="nav navbar-nav custom">
		<li>
		<a class="logo" rel="home" href="/index.php" title="Buy Sell Rent Everyting">
        <img style="height:35px; dislay:inline-block;"
             src="/Images/logo.png">
		</a></li>



		<li><a id="gallery" href="/gallery.php">
		Галерия
		</a></li>
	</ul>
	<ul class="nav navbar-nav navbar-right custom">
		<?php
		if ($_SESSION['login_user']!=null){
		echo "<li><a href='#'>Здравей, ".$_SESSION['login_user']."</a></li>
		<li><a id='loogout' href='/logout.php'>
		Изход
		</a></li>";
		} else {
		echo '
		<li><a id="login" href="/login.php">
		Вход
		</a></li>
		<li><a id="login" href="/user.php">
		Регистрация
		</a></li>';
		}
		?>
	</ul>
	</div>
</nav>