$(document).ready(function() {
	/* activate the carousel */
	/*$("#modal-carousel").carousel({interval:false});*/
	/* change modal title when slide changes */
	$("#modal-carousel").on("slid.bs.carousel", function () {
		$(".modal-title")
		.html($(this)
		.find(".active")
		.attr("alt"));
	});
	/* when clicking a thumbnail */
	$(".item").click(function(){
		
		var content = $(".carousel-inner");
		var title = $(".modal-title");
		content.empty();  
		title.empty();
  	var id = this.id;  
     var repo = $(".item");
    var repoCopy = repo.clone();
     var active = repoCopy.filter("#" + id);
  
    active.addClass("active");
   title.text(active.find("img").attr("alt"));
  	content.append(repoCopy);

    // show the modal
  	$("#modal-gallery").modal("show");
  });

});