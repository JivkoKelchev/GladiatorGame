<?php

/* връзка с база данни */

$servername = "localhost"; $username = "jivkokel"; $password = "kzYn[Kt4X)9A";

$dbname = "jivkokel_pics";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) { die("Connection failed: " . mysqli_connect_error()); }

?>