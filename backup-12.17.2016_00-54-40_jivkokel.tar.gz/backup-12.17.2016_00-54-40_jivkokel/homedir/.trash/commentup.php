<form action= "<?php echo "$_SERVER[PHP_SELF]"; ?>" method="post">
<textarea name="textarea" style="width:250px;height:150px;"></textarea>
<input type='submit' name='<?php echo $_SESSION["picID"]; ?>' value='Добави коментар'>
</form>

<?php
include 'dbconnect.php';
$comment=$_POST['textarea'];
$submit=$_POST[$_SESSION["picID"]];
if ( $submit=='Добави коментар'){
	$sql_query2= 'insert into comments(comment,picID,userID)
	values ("'.$comment.'",'.$_SESSION["picID"].','.$_SESSION["login_userID"].')';
	$result2 = mysqli_query($conn, $sql_query2);
	if($result2){
		echo "<script> alert(Добави коментар) </script>";
	} else{
		echo "<script> alert(Възникна проблем с връзката със сървъра) </script>";
	}
}