<!DOCTYPE html>

<html>

<head>

<meta charset="utf-8">

</head>

<body>

<?php
/* upload.php за форма за качване на снимки*/
include 'dbconnect.php';

$submit=$_POST['submit'];
if ($submit=="Upload Image"){

$target_dir='upload/';
$target_file=$target_dir.basename($_FILES["fileToUpload"]["name"]);
$pictypeID=$_POST['pictypeID'];
$countryID=$_POST['countryID'];
$description=$_POST['description'];
$country=$_POST['country'];

if ( $countryID == '' ) {

   if ($country == '') { 
     echo '<script> alert("Попълни или избери държава") </script>';
     include 'form.php';     
     exit;
   } else { 
     $sql_query = "INSERT INTO country (country)

     VALUES ('$country');";

     $result = mysqli_query($conn, $sql_query);
             if($result){
                 $sql_query = "select countryID from country where country = '$country'";
                 $result = mysqli_query($conn, $sql_query);
                       if (mysqli_num_rows($result) > 0) {
                         while($row = mysqli_fetch_assoc($result)) {
                         $countryID = $row["countryID"];
                         }
                       }
             } else{
                 echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
             }
    }

}


echo $pictypeID.'<br>'.$countryID.'<br>';

if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {

echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been

uploaded.";

} else {

echo "Sorry, there was an error uploading your file.";

};

include 'dbconnect.php';

$sql_query = "INSERT INTO pics (filename, description, countryID, pictypeID)

VALUES ('$target_file', '$description', '$countryID', '$pictypeID');";

$result = mysqli_query($conn, $sql_query);

if($result){
    echo "Records added successfully.";
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
}

}/*това  е края на if ($submit=="Upload Image")*/







/* za fail user.php*/

  elseif ($submit=='Register'){

     $username=$_POST['username'];
     $pass=$_POST['pass'];
     $pass1=$_POST['pass1'];

        if  ($username=="" || $pass=="" || $pass1==""){

         echo '<script> alert("Не си попълнил username или pass") </script>';
         include 'user.php';
         exit;
        } elseif ($username!=="" && $pass!=="" && $pass1!==""){
             if ($pass!==$pass1){
                echo '<script> alert("Паролите са различни!") </script>';
                include 'user.php';
                exit;
             }else {
                 if ( strlen('$pass') < 6 ) {
                       echo '<script> alert("Паролата трябва да е поне 6 символа") </script>';
                       include 'user.php';
                       exit; 
                  } else {
                     $password=$pass;
                  }
             } 
             $sql_query = "SELECT username FROM user where username = '$username'";

             $result = mysqli_query($conn, $sql_query);

                if (mysqli_num_rows($result) > 0) {
                       echo '<script> alert("потребителското име е заето!") </script>';
                       include 'user.php';
                       exit;                 
                } else {
                   $user=$username;
                }
                $sql_query = "INSERT INTO user (username, pass)
                VALUES ('$user', '$password');";
                $result = mysqli_query($conn, $sql_query);
                   if($result){
                   echo "Records added successfully.";
                   } else{
                       echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
                   }
          }
        




  }


mysqli_close($conn);

?>

</body>

</html>