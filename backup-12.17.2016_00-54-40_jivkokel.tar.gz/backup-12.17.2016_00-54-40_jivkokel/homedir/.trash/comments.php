<?php
session_start();
function comments(){
include 'dbconnect.php';
if ($_SESSION['login_user']==null){
$sql_query="Select comments.comment,comments.date, user.username
from comments 
left join user on user.userID=comments.userID
where picID = ".$_SESSION['picID']."
order by date desc";

$result=mysqli_query($conn,$sql_query);
	if (mysqli_num_rows($result)>0){
		while($row = mysqli_fetch_assoc($result)){
		echo '<p id="comment">'.$row["username"].':<br>'.$row["comment"].'<br>'.$row["date"].'</p><br>';
		}
	} else {
	echo '<p id="nocomment">Още няма написани коментари.<p>';
	}
} else {
$sql_query="Select comments.comment,comments.date, user.username
from comments 
left join user on user.userID=comments.userID
where picID = ".$_SESSION['picID']."
order by date desc";

$result=mysqli_query($conn,$sql_query);
	if (mysqli_num_rows($result)>0){
		while($row = mysqli_fetch_assoc($result)){
		echo '<p id="comment">'.$row["username"].':<br>'.$row["comment"].'<br>'.$row["date"].'</p><br> ';
		}
		include 'commentup.php';
	} else {
		echo '<p id="nocomment">Още няма написани коментари.<p><br>';
		include 'commentup.php';
	}
}
}
?>