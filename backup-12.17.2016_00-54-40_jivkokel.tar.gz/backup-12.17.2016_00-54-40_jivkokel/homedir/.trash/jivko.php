<?php

/*$servername = "localhost"; $username = "jivkokel"; $password = "kzYn[Kt4X)9A";

$dbname = "jivkokel_orders";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) { die("Connection failed: " . mysqli_connect_error()); }

$sql_query = "SELECT customerid, customername FROM Customers";

$result = mysqli_query($conn, $sql_query);

if (mysqli_num_rows($result) > 0) {

	echo "<table border=1 style='border-collapse: collapse;'> ";
	echo "<tr> <td> <b>id:</b></td> <td>  <b> Name:</b></td>";
	while($row = mysqli_fetch_assoc($result)) {
	

	echo "<tr> <td> ". $row["customerid"] ."</td> <td> ".  $row["customername"]." </td>";
	

} 
echo "</table>";}
else {

echo "0 results";

}

mysqli_close($conn);*/

$exif_data = exif_read_data('upload/IMAG2187.jpg');
print_r($exif_data);

?>