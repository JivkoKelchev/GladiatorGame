-- cPanel mysql backup
GRANT USAGE ON *.* TO 'jivkokel'@'localhost' IDENTIFIED BY PASSWORD '*3612CD80C103D11AA898EAF7B5B267D8080292FC';
GRANT ALL PRIVILEGES ON `jivkokel\_orders`.* TO 'jivkokel'@'localhost';
GRANT ALL PRIVILEGES ON `jivkokel\_pics`.* TO 'jivkokel'@'localhost';
GRANT USAGE ON *.* TO 'jivkokel_orders'@'localhost' IDENTIFIED BY PASSWORD '*21369A85BE1B4F9B354A802FB817D48841984690';
GRANT ALL PRIVILEGES ON `jivkokel\_orders`.* TO 'jivkokel_orders'@'localhost';
